/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  main.c
Description      :  Basic functions to setup the PIC18F4550, enter bootloader
                    and program the bootloader with new firmware
Author           :  Alwino van der Merwe
Date             :  26/11/13
Revision         :  V1.0
*******************************************************************************/

#ifndef USBMOUSE_C
#define USBMOUSE_C

#include "includes.h"

// Ensure we have the correct target PIC device family
#if !defined(__18F4550)
	#error "This firmware only supports the PIC18F4550 microcontroller."
#endif
/*********************************************************************************************************************
*PRAGMA SECTION
* Configuration for PIC18f4550
********************************************************************************************************************/
#pragma config PLLDIV   = 2         // 20MHz external oscillator
#pragma config CPUDIV   = OSC1_PLL2 // 48MHz clock cycle --- 4 cycles per instruction --> 12 mips
#pragma config USBDIV   = 2         // Clock source from 96MHz PLL/2
#pragma config FOSC     = HSPLL_HS
#pragma config FCMEN    = OFF
#pragma config IESO     = OFF
#pragma config PWRT     = OFF		// PowerUp timer OFF
#pragma config BOR      = ON		// brown out detect ON
#pragma config BORV     = 3
#pragma config WDT      = OFF		// watchdog timer off
#pragma config WDTPS    = 32768
#pragma config MCLRE    = ON
#pragma config LPT1OSC  = OFF
#pragma config PBADEN   = OFF		// PORTB<4:0> as digital IO on reset
#pragma config STVREN   = ON
#pragma config LVP      = OFF		// low level voltage OFF
#pragma config XINST    = OFF
#pragma config CP0      = OFF
#pragma config CP1      = OFF
#pragma config CPB      = OFF
#pragma config WRT0     = OFF
#pragma config WRT1     = OFF
#pragma config WRTB     = OFF
#pragma config WRTC     = OFF
#pragma config EBTR0    = OFF
#pragma config EBTR1    = OFF
#pragma config EBTRB    = OFF
/*********************************************************************************************************************
                            GLOBAL VARIABLES
********************************************************************************************************************/

#define Light0 LATDbits.LATD0
#define Light1 LATDbits.LATD1
#define Light2 LATDbits.LATD2
#define Light3 LATDbits.LATD3

unsigned char success = 0;
unsigned char firstFlag = 0; // flag to show if bootloader was written to
unsigned char successFlag = 0;    // 1 = Firmware write was successful; 0 = unsuccessful
/*********************************************************************************************************************
				MAIN
********************************************************************************************************************/
void main(void)
{
    /* initialise the hardware setup of the PIC18F4550  */
    initialisePic();
   
    /* do ACK polling to attempt to enter the bootloader */
    success = ackPolling();

    /* if succesful entry was gained into the bootloader, read the
     * bootloader version and do a redundency (CRC) check (optional) to confirm
     * successful bootloader entry
     */
    if (success)
    {
         readBootloaderVersion();    // read bootloader version
    }

    while(1)
    {
        /* failsafe: Enter bootloader by resetting IQS5xx with a command that
         * resets the IQS5xx with the bootloader flag true. The command is
         * 0xA5 to register 0xFF. Give the IQS5xx time to startup and then
         * read version info and then the bootloader may be programmed.
         */
        if (!success)
        {
            // send the instruction to restart the IQS5xx in bootloader
            resetDeviceWithBootLoadInstruction();

            delay_ms(50);   // create a delay to give the IQS5xx time to reset in bootloader

            // now the bootloader version can be read
            readBootloaderVersion();    // read bootloader version if successful entry

            success = 1; // do net enter again
        }

        /* If it is the first run through, as well as a successful bootloader
         * entry, program the device. Set the flag so that programming occurs
         * only once.
         */
        if (!firstFlag && success)
        {
            successFlag = programBootloader(); // program the bootloader
            firstFlag = 1;                     // do not program again
        }

        // indicate via LEDs that write was successful
        if (successFlag)
        {
            delay_ms(150);
            LATD = 0x0F;    // lights off when finished
            delay_ms(150);
            LATD = 0x00;    // lights on when finished
            delay_ms(150);
            LATD = 0x0F;    // lights off when finished
            delay_ms(150);
            LATD = 0x00;    // lights on when finished
        }
        // if the write was not successful, show with one LED flashing
        else if (!successFlag)
        {
            delay_ms(150);
            Light0 = 1;
            delay_ms(150);
            Light0 = 0;
            delay_ms(150);
            Light0 = 1;
            delay_ms(150);
            Light0 = 0;
        }

    } // end of main loop
  
     
}   /* End of main () */

#endif

