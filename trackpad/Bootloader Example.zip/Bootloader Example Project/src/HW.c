/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  HW.c
Description      :  All the Hardware is setup and initialised here
Author           :  Alwino van der Merwe
Date             :  28/11/13
Revision         :  V1.0
*******************************************************************************/


#include "includes.h"


// Initialise the PIC
void initialisePic(void)
{
	ADCON1 = 0x0F;								//PORTA all digital operation
	LATA = 0x02;
	TRISA = 0x02;								//RA3 is power output for IQS5xx, RA1 (RDY) input.
	TRISD = 0x00; 								//configure PORTD for output
        LATD = 0x0F;								//LEDS off

	LATB = 0xFF;
	TRISB = 0xBF;								//PORTB for input except bit6 for output
	INTCON2bits.RBPU = 0;                                                   //For PIC18LF4550-Eval-Rev4A hardware with 74HC573 latch
	TRISCbits.TRISC0 = 0;
	LATCbits.LATC0  = 1;                                                    //un-latch 74HC573 to make OUTD follows LATD
	TRISCbits.TRISC1 = 0;                                                   //enable the latch
	LATCbits.LATC1 = 0;

	LATB = 0xFF;
	LATD = 0x0F;								// LEDS off

        // initialises the 5ms timer
        init_Timer();

        // initialise I2C hardware module
        Comms_init();

}

/*********************************************************************************************************************                  
 *                      --- void init_Timer(void) ---
 *          This function initialises a timer that executes every 1.36s
********************************************************************************************************************/
void init_Timer(void)
{
    // Timer0 configuration
    T0CONbits.TMR0ON = 0; // Stop the timer
    T0CONbits.T08BIT = 1; // Run in 8-bit mode
    T0CONbits.T0CS = 0; // Use system clock to increment timer
    T0CONbits.PSA = 0; // A prescaler is assigned for Timer0
    T0CONbits.T0PS2 = 1; // Use a 1:x prescaler
    T0CONbits.T0PS1 = 1;
    T0CONbits.T0PS0 = 1;
    TMR0L = 0x00;
    TMR0H = 0x00;
    INTCONbits.GIEH = 1;
    INTCONbits.TMR0IE = 1;
    INTCONbits.TMR0IF = 1;
    T0CONbits.TMR0ON = 1; // Start the timer
}
/*********************************************************************************************************************
			Main Interrupt Service Routine (ISR)void interrupt ISR()
********************************************************************************************************************/
#pragma code isr = 0x08 // Store the below code at address 0x08
#pragma interrupt isr
void isr(void)
{
    // service routine for the timer interrupt
    if(INTCONbits.TMR0IF)
    {
        // handle interrupt and reset control register
        INTCONbits.TMR0IE = 0;
        INTCONbits.TMR0IF = 0;
        INTCONbits.TMR0IE = 1;
        TMR0L = 0x00;
    }
}
#pragma code // Return to the default code section
/*********************************************************************************************************************

********************************************************************************************************************/
