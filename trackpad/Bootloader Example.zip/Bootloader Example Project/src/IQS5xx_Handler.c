/******************************************************************************
*                                                                             	*
*                            Module specification                              	*
*                                                                             	*
*                                Copyright by                                 	*
*                                                                            	*
*                              Azoteq (Pty) Ltd                              	*
*                          Republic of South Africa                           	*
*                                                                             	*
*                           Tel: +27(0)21 863 0033                            	*
*                          E-mail: info@azoteq.com                            	*
*                                                                             	*
*********************************************************************************
Name             :  IQS5xx_Handler.c
Description      :  This controls the IQS5xx. For this implementation, only the
                 :  bootloader specific funtions is defined and used
Author           :  Alwino van der Merwe
Date             :  28/11/13
Revision         :  V1.2
*******************************************************************************/


#include "includes.h"
#include "HEX_Array.h"

/*  DEFINES */
#define BOOTLOADER_WRITES 240   // the bootloader size is fixed at 15360 bytes - thus program the complete space with 240 writes of 64 bytes per write
#define BLOCK_SIZE         64   // size data that the bootloader requires for a write to occur
#define ERR                 0
#define SUCCESS             1

#define Light0 LATDbits.LATD0
#define Light1 LATDbits.LATD1
#define Light2 LATDbits.LATD2
#define Light3 LATDbits.LATD3

/*  GLOBAL VARIABLES    */
// try and minimize global variables if possible
unsigned char data_buffer [66]; // hold the i2c data, as well as address
int address = 0x8400; // starting address of the bootloader
int index = 0; // Hold the index from where the HEX array needs to be loaded now

/* Remember that the HEX array is very large, thus it is located in ROM and not
 * in RAM!
 */

/**
 * Read the bootloader version that is on the IQS5xx device. This will indicate
 * a successful entry into the bootloader. The current bootloader version is
 * V2.0 and is received as 0x20, 0x00.
 */
void readBootloaderVersion (void)
{  
    CommsIQS_bootloader_start();
    CommsIQS_Read(IQS5XX_BOOTLOADER_ADDR, 0x00, &data_buffer[0], 2);
    CommsIQS_bootloader_stop();
    delay_ms(10);
}   /*  End readBootloaderVersion() */

/**
 * If the bootloader couldn't be entered with ACK polling, this command can be
 * sent to force the IQS5xx to restart with the bootloader flag set. Please note
 * that the command, 0xA5 is sent to the APPLICATION and written in register
 * 0xFF. Thus, note that the I2C address is that of the IQS5xx and NOT the
 * bootloader
 */
void resetDeviceWithBootLoadInstruction(void)
{
    data_buffer[0] = 0xA5;  // enter bootloader command, after reset
    CommsIQS_bootloader_start();
    CommsIQS_Write(IQS5XX_ADDR, 0xFF, &data_buffer[0], 1); // send the enter bootload command
    CommsIQS_bootloader_stop();
}   /*  End resetDeviceWithBootLoadInstruction() */

/**
 * This is a CRC check that the bootloader performs on its firmware. If 0x00 is
 * returned, everything adds up with the firmware. Do this to confirm if the
 * IQS5xx has accepted the firmware
 * @NOTE At the moment this function is not working correctly on the current
 * testing firmware
 * @return
 */
unsigned char doRedundencyCheck(void)
{
    CommsIQS_bootloader_start();
    CommsIQS_Read(IQS5XX_BOOTLOADER_ADDR, 0x03, &data_buffer[0], 1); // send the Do CRC check command
    CommsIQS_bootloader_stop();

    return data_buffer[0];
}   /*  End doRedundencyCheck() */

unsigned char programBootloader (void)
{

    long int i,j;
    unsigned char counter = 0; // keep count from where we are

    Light0 = 1;
    Light1 = 1;
    Light2 = 1;
    Light3 = 1;
    
    for (j = 0; j < BOOTLOADER_WRITES; j++)
    {
        
        data_buffer[0] = (address & 0xFF00) >> 8; // only MSB of address
        data_buffer[1] = (address & 0x00FF); // only LSB of address
        for (i = index; i < (index + BLOCK_SIZE); i++)
        {
            data_buffer[counter+2] = hex_array[i];  // copy the hex array to the buffer
            counter++;
        }
        // increase index to the position we are in now - 64 later
        index += counter;
        counter = 0; // reset counter
        // now initiate a bootloader write
        CommsIQS_bootloader_start();
        CommsIQS_Write_Bootloader_Program(IQS5XX_BOOTLOADER_ADDR, &data_buffer[0], BLOCK_SIZE+2); // write the data to bootloader via i2c
        CommsIQS_bootloader_stop();

        /* This delay is necessary to give the bootloader some time to write the
         * 64 byte buffer into memory
         * This delay is only necessary after each block write
         */
        delay_ms(7); // create a delay to give bootloader some time to write

        /*  Show Lights as indication of progress - mainly for debugging  */
        if (j == BOOTLOADER_WRITES/4)
            Light0 = 0;
        if (j == BOOTLOADER_WRITES/2)
            Light1 = 0;
        if (j == BOOTLOADER_WRITES*3/4)
            Light2 = 0;
        if (j == BOOTLOADER_WRITES-1)
            Light3 = 0;

        address += BLOCK_SIZE;   // increment the address with [64] bytes

    }

    /* Flash lights to indicate writing is done - mainly for debugging */
    delay_ms(5); // create a delay to give bootloader some time to write
    LATD = 0x0F;    // lights off when finished
    delay_ms(5); // create a delay to give bootloader some time to write
    LATD = 0x00;    // lights on when finished
    delay_ms(5); // create a delay to give bootloader some time to write
    LATD = 0x0F;    // lights off when finished

   if (verify_data())
        return SUCCESS;
   else
       return ERR;
}   /*  End programBootloader() */

/**
 * This function reads blocks of 64 bytes data from the bootloader.
 * This is then compared to the array which was written and if successful return
 * success, else return ERROR
 * @return
 */
unsigned char verify_data (void)
{

    long int i,j;
    unsigned char counter = 0; // keep count from where we are
    address = 0x8400;   // restart from the beginning of the firmware
    index = 0;          // reset the index - start from the beginning

    Light0 = 1;
    Light1 = 1;
    Light2 = 1;
    Light3 = 1;

    for (j = 0; j < BOOTLOADER_WRITES; j ++)
    {

        data_buffer[0] = (address & 0xFF00) >> 8; // only MSB of address
        data_buffer[1] = (address & 0x00FF); // only LSB of address

        /*  After each write, read back and compare to verify the written block */
        CommsIQS_bootloader_start();
        CommsIQS_Read_Bootloader(IQS5XX_BOOTLOADER_ADDR, data_buffer[0], data_buffer[1], &data_buffer[2], BLOCK_SIZE); // read the data to bootloader via i2c
        CommsIQS_bootloader_stop();
        
        for (i = index; i < (index + BLOCK_SIZE); i++)
        {
            if (data_buffer[counter+2] != hex_array[i])  // copy the hex array to the buffer
                return ERR;
            
            counter++;
        }
        // increase index to the position we are in now - 64 later
        index += counter;
        counter = 0; // reset counter

        address += BLOCK_SIZE;   // increment the address with [64] bytes

        /*  Show Lights as indication of progress   */
        if (j == BOOTLOADER_WRITES/4)
            Light0 = 0;
        if (j == BOOTLOADER_WRITES/2)
            Light1 = 0;
        if (j == BOOTLOADER_WRITES*3/4)
            Light2 = 0;
        if (j == BOOTLOADER_WRITES-1)
            Light3 = 0;

    }

     /* Flash lights to indicate readings is done and successful - mainly for debugging */
    delay_ms(20); // create a delay to give bootloader some time to write
    LATD = 0x0F;    // lights off when finished
    delay_ms(20); // create a delay to give bootloader some time to write
    LATD = 0x00;    // lights on when finished
    delay_ms(20); // create a delay to give bootloader some time to write
    LATD = 0x0F;    // lights off when finished
    delay_ms(20); // create a delay to give bootloader some time to write
    LATD = 0x00;    // lights on when finished

    return SUCCESS;
}   /*  End verify_data() */
