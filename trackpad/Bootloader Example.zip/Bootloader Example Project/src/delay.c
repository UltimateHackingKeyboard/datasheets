
/*********************************************************************************************************************

		Azoteq

		PIC18f4550 delay functions for current setup

********************************************************************************************************************/

#include "includes.h"

/**
 * Create an approximate 100us delay. This was tuned for the specific MCU. A
 * more accurate delay can be made by using timers
 */
void delay_100us(void)
{
	unsigned char i;
	unsigned char j = 0;

	for (i = 0; i < 90; i++)
	{
		j++;
	}

}

void delay_1ms(void)
{
	unsigned char i;

	for (i = 0; i < 15; i++)
	{
		delay_100us();
	}
}

/**
 * Create a delay that is approximately ms x ms long. Thus for @param 1000 would
 * be a 1 second delay (approx)
 * @param ms
 */
void delay_ms(unsigned int ms)
{
	unsigned int i;

	for (i = 0; i < ms; i++)
	{
		delay_1ms();
	}
}

/**
 * Create a delay that is almos 10us long
 */
void delay_10us (void)
{
    unsigned char i;
    unsigned char j = 0;
    for (i = 0; i <= 10; i++)
    {
        j++;
    }
}