/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  includes.h
Description      :  All the header files to include
Author           :  Alwino van der Merwe
Date             :  24/07/13
Revision         :  V1.3.1
*******************************************************************************/


#ifndef INCLUDES_H
#define	INCLUDES_H

//Common definitions
#include "Compiler.h"
#include <p18f4550.h>

// PIC
#include "HW.h"
#include "i2c_low_level.h"
#include "i2c_high_level.h"
#include "delay.h"

// IQS 5xx
#include "IQS5xx.h"
#include "IQS5xx_handler.h"


#endif

