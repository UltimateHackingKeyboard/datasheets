/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  IQS5xx.h
Description      :  IQS5xx general header file that defines the I2C address
                 :  of the IQS5xx and the bootloader
Author           :  Alwino van der Merwe
Date             :  28/11/13
Revision         :  V1.0
*******************************************************************************/

#ifndef IQS_5xx_H
#define IQS_5xx_H
#endif

// i2c slave device address
#define IQS5XX_ADDR 0x74
#define IQS5XX_BOOTLOADER_ADDR 0x34

#define PRODUCT_NUMBER 0x20

// Definitions of read-only Address-commands implemented on IQS360
#define	VERSION_INFO		0x00	// Product number can be read :2 bytes
#define FLAGS 			0x01	// System flags and events 	  :2 bytes
#define XY			0x02	// X-Y coordinates            :4 bytes
#define SNAP_TOUCH_STATUS	0x03	// Touch and snap channels    :4 bytes

