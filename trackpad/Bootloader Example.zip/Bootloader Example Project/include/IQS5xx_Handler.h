/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  IQS5xx_Handler.h
Description      :  Header file of the functions used used in IQS5xx_Handler.c
Author           :  Alwino van der Merwe
Date             :  28/11/13
Revision         :  V1.0
*******************************************************************************/

#ifndef IQS5XX_HANDLER_H
#define	IQS5XX_HANDLER_H

void readBootloaderVersion (void);
void resetDeviceWithBootLoadInstruction(void);
unsigned char doRedundencyCheck(void);
unsigned char programBootloader (void);
unsigned char verify_data (void);
