/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  i2c_low_level.h
Description      :  Header file of i2c_low_level.c
Author           :  Alwino van der Merwe
Date             :  28/11/13
Revision         :  V1.0
*******************************************************************************/

#ifndef I2C_LOW_LEVEL_H
#define I2C_LOW_LEVEL_H


#define POLLING_ATTEMPTS 1

void Comms_init(void);
unsigned char ackPolling (void);
unsigned char CommsIQS_send(unsigned char send_data);
unsigned char CommsIQS_read_ack(void);
unsigned char CommsIQS_read_nack(void);
void CommsIQS_start(void);
void CommsIQS_bootloader_start(void);
void CommsIQS_repeat_start(void);
void CommsIQS_stop(void);
void CommsIQS_bootloader_stop(void);  // this stop does not watch RDY line
// Functions for the CT-Tool i2c commands
unsigned char Comms_send(unsigned char send_data);
unsigned char Comms_start(void);
unsigned char Comms_repeat_start(void);
