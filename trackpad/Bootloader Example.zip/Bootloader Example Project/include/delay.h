/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  delay.h
Description      :  Header file of delay.c
Author           :  Alwino van der Merwe
Date             :  28/11/13
Revision         :  V1.0
*******************************************************************************/

#ifndef DELAY_H
#define DELAY_H

void delay_100us(void);
void delay_1ms(void);
void delay_ms(unsigned int ms);
void delay_10us (void);

