/******************************************************************************
*                                                                             *
*                            Module specification                             *
*                                                                             *
*                                Copyright by                                 *
*                                                                             *
*                              Azoteq (Pty) Ltd                               *
*                          Republic of South Africa                           *
*                                                                             *
*                           Tel: +27(0)21 863 0033                            *
*                          E-mail: info@azoteq.com                            *
*                                                                             *
*******************************************************************************
Name             :  i2c_high_level.h
Description      :  Header file of i2c_high_level.c
Author           :  Alwino van der Merwe
Date             :  28/11/13
Revision         :  V1.0
*******************************************************************************/

#ifndef I2C_HIGH_LEVEL_H
#define	I2C_HIGH_LEVEL_H


void CommsIQS_Write(unsigned char i2c_addr, unsigned char write_addr, unsigned char *data, unsigned char NoOfBytes);
void CommsIQS_Read(unsigned char i2c_addr, unsigned char read_addr, unsigned char *data, unsigned char NoOfBytes);
void CommsIQS_Read_Bootloader(unsigned char i2c_addr, unsigned char msb_Addr, unsigned char lsb_Addr, unsigned char *data, unsigned char NoOfBytes);
void CommsIQS_Write_Bootloader_Program(unsigned char i2c_addr, unsigned char *data, unsigned char NoOfBytes);


#endif	/* I2C_HIGH_LEVEL_H */

